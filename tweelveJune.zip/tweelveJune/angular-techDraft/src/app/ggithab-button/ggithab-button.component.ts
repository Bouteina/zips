import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ggithab-button',
  templateUrl: './ggithab-button.component.html',
  styleUrls: ['./ggithab-button.component.css']
})
export class GgithabButtonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
