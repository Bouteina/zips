import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newsletterform',
  templateUrl: './newsletterform.component.html',
  styleUrls: ['./newsletterform.component.css']
})
export class NewsletterformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
