import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shaks-call-to-action-comp',
  templateUrl: './shaks-call-to-action-comp.component.html',
  styleUrls: ['./shaks-call-to-action-comp.component.css']
})
export class ShaksCallToActionCompComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
